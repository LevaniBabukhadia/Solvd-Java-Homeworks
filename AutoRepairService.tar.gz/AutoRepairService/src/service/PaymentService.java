package service;

import model.Part;
import model.RepairOrder;
import java.math.BigDecimal;

public class PaymentService {

    public BigDecimal calculateTotal(RepairOrder order) {
        BigDecimal total = BigDecimal.ZERO;
        for (Part part : order.getParts()) {
            total = total.add(part.getPrice());
        }
        return total;
    }

    public void pay(RepairOrder order) {
        BigDecimal total = calculateTotal(order);
        System.out.println("Payment of $" + total + " received for order " + order.getOrderId());
    }
}
