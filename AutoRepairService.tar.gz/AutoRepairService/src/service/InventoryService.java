package service;

import model.Part;

public class InventoryService {

    private Part[] availableParts;

    public InventoryService(Part[] availableParts) {
        this.availableParts = availableParts;
    }

    public Part[] getAvailableParts() {
        return availableParts;
    }

    public void setAvailableParts(Part[] availableParts) {
        this.availableParts = availableParts;
    }
}

