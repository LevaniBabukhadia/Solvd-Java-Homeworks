package service;

import model.RepairOrder;

public class OrderService {

    public void completeOrder(RepairOrder order) {
        if (!order.isCompleted()) {
            order.setCompleted(true);
            System.out.println("Order " + order.getOrderId() + " completed.");
        } else {
            System.out.println("Order already completed.");
        }
    }
}

