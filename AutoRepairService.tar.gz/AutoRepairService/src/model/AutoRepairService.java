package model;

public class AutoRepairService {

    private Customer[] customers;
    private Employee[] employees;
    private Car[] cars;
    private RepairOrder[] orders;
    private Part[] parts;

    public AutoRepairService(Customer[] customers, Employee[] employees, Car[] cars, RepairOrder[] orders, Part[] parts) {
        this.customers = customers;
        this.employees = employees;
        this.cars = cars;
        this.orders = orders;
        this.parts = parts;
    }

    public Customer[] getCustomers() {
        return customers;
    }

    public void setCustomers(Customer[] customers) {
        this.customers = customers;
    }

    public Employee[] getEmployees() {
        return employees;
    }

    public void setEmployees(Employee[] employees) {
        this.employees = employees;
    }

    public Car[] getCars() {
        return cars;
    }

    public void setCars(Car[] cars) {
        this.cars = cars;
    }

    public RepairOrder[] getOrders() {
        return orders;
    }

    public void setOrders(RepairOrder[] orders) {
        this.orders = orders;
    }

    public Part[] getParts() {
        return parts;
    }

    public void setParts(Part[] parts) {
        this.parts = parts;
    }
}
