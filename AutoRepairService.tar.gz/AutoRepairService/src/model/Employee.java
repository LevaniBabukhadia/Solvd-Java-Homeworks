package model;

import java.time.LocalDateTime;

public class Employee {

    private String name;
    private String position;
    private boolean isFullTime;
    private LocalDateTime hiredAt;

    public Employee(String name, String position, boolean isFullTime, LocalDateTime hiredAt) {
        this.name = name;
        this.position = position;
        this.isFullTime = isFullTime;
        this.hiredAt = hiredAt;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public boolean isFullTime() {
        return isFullTime;
    }

    public void setFullTime(boolean fullTime) {
        isFullTime = fullTime;
    }

    public LocalDateTime getHiredAt() {
        return hiredAt;
    }

    public void setHiredAt(LocalDateTime hiredAt) {
        this.hiredAt = hiredAt;
    }
}
