package model;

import java.time.LocalDate;

public class Customer {

    private String name;
    private String phone;
    private LocalDate registrationDate;

    public Customer(String name, String phone, LocalDate registrationDate) {
        this.name = name;
        this.phone = phone;
        this.registrationDate = registrationDate;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public LocalDate getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(LocalDate registrationDate) {
        this.registrationDate = registrationDate;
    }
}

