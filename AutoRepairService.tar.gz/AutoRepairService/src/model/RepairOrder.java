package model;

import java.time.LocalDateTime;

public class RepairOrder {

    private int orderId;
    private Customer customer;
    private Car car;
    private Part[] parts;
    private boolean isCompleted;
    private LocalDateTime createdAt;

    public RepairOrder(int orderId, Customer customer, Car car, Part[] parts, LocalDateTime createdAt) {
        this.orderId = orderId;
        this.customer = customer;
        this.car = car;
        this.parts = parts;
        this.isCompleted = false;
        this.createdAt = createdAt;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public Part[] getParts() {
        return parts;
    }

    public void setParts(Part[] parts) {
        this.parts = parts;
    }

    public boolean isCompleted() {
        return isCompleted;
    }

    public void setCompleted(boolean completed) {
        isCompleted = completed;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
