package app;

import model.*;
import service.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class MainApp {

    public static void main(String[] args) {
        AutoShopInfo.printInfo();

        Customer customer = new Customer("John Doe", "555-1234", LocalDate.now());
        Employee mechanic = new Employee("Mike", "Mechanic", true, LocalDateTime.now());
        Car car = new Car("AB-123-CD", "Toyota Corolla", 2015);

        Part oilFilter = new Part("Oil Filter", new BigDecimal("25.50"));
        Part brakePad = new Part("Brake Pad", new BigDecimal("70.00"));
        Part[] parts = {oilFilter, brakePad};

        RepairOrder order = new RepairOrder(1, customer, car, parts, LocalDateTime.now());

        Customer[] customers = {customer};
        Employee[] employees = {mechanic};
        Car[] cars = {car};
        RepairOrder[] orders = {order};
        Part[] allParts = {oilFilter, brakePad};

        AutoRepairService autoRepairService = new AutoRepairService(customers, employees, cars, orders, allParts);

        OrderService orderService = new OrderService();
        PaymentService paymentService = new PaymentService();
        InventoryService inventoryService = new InventoryService(allParts);

        paymentService.pay(order);
        orderService.completeOrder(order);
        System.out.println("Thanks for visiting Levani's shop");

    }
}
