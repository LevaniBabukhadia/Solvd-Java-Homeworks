package app;

public class AutoShopInfo {

    public static String shopName;
    public static String address;

    static {
        shopName = "Levani's shop, just the best!";
        address = "Tbilisi, Zgvis Ubani,21/a";
        System.out.println("Welcome to " + shopName + " located at " + address);
    }

    public static void printInfo() {
        System.out.println("AutoShop: " + shopName + " | Address: " + address);
    }
}
