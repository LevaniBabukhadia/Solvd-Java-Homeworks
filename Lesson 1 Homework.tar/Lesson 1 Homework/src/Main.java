import java.util.Arrays;


public class Main {
    public static void main(String[] args) {

                // selection sort by ascending order by Levani Babukhadia
                // it is done without functions

                // creating the array
                double[] MyArray = {64, -2,2.56,-34,34, 25, 12, 22, 11, 1,90};

                System.out.println("Initial array is: "+Arrays.toString(MyArray));


                // Selection sort algorithm
                for (int i = 0; i < MyArray.length - 1; i++) {
                    // Finding the minimum element in remaining unsorted array
                    int minIndex = i;
                    for (int j = i + 1; j < MyArray.length; j++) {
                        if (MyArray[j] < MyArray[minIndex]) {
                            minIndex = j;
                        }
                    }

                    // Swap the  minimum element with the first element
                    double temp = MyArray[minIndex];
                    MyArray[minIndex] = MyArray[i];
                    MyArray[i] = temp;
                }

                // Print sorted array
                System.out.println("Sorted array is :"+Arrays.toString(MyArray));


    }
}